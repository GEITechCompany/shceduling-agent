# Scheduling Assistant Frontend

A modern, responsive frontend for the Scheduling Assistant application, optimized for deployment on Hostinger.

## Overview

This frontend is built with plain HTML, CSS, and JavaScript, making it compatible with any standard web hosting service like Hostinger. It connects to your existing Flask backend API.

## File Structure

- `index.html` - Main HTML file
- `styles.css` - CSS styles
- `config.js` - Configuration settings
- `app.js` - Application logic
- `favicon.ico` - Site favicon

## Deployment to Hostinger

Follow these steps to deploy this frontend to Hostinger:

1. **Log in to your Hostinger account**

2. **Upload Files**
   - Go to File Manager in your Hostinger control panel
   - Navigate to your domain's public_html directory
   - Upload all files from this folder to the public_html directory
   - Alternatively, you can use FTP to upload the files

3. **Configure API Connection**
   - Once deployed, visit your website
   - Click the settings icon (gear) in the chat interface
   - Enter your API backend URL (e.g., `https://your-api-domain.com/api/chat`)
   - If your API requires authentication, enter your API key
   - Click "Save Settings"

## Backend API Requirements

The frontend expects the API to:

1. Accept POST requests to the endpoint specified in settings
2. Receive JSON with a `message` field containing the user's message
3. Return JSON with a `response` field containing the assistant's response

Example request:
```json
{
  "message": "I want to schedule a window cleaning service"
}
```

Example response:
```json
{
  "response": "I'd be happy to help you schedule window cleaning service. When would you like to schedule it?"
}
```

## Customization

You can customize the frontend by:

1. Editing the `config.js` file to change default settings
2. Modifying the HTML structure in `index.html`
3. Updating styles in `styles.css`
4. Extending functionality in `app.js`

## Backend Hosting

If your backend is not yet deployed, consider these options:

1. **VPS/Dedicated Server** - Deploy your Flask app on a VPS from providers like DigitalOcean, Linode, or AWS EC2.
2. **Platform as a Service** - Deploy on services like Heroku, Render, or PythonAnywhere.

Remember to update your Flask app with appropriate CORS settings:

```python
from flask_cors import CORS
app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})  # For development only
```

For production, replace "*" with your specific frontend domain.

## Troubleshooting

If the assistant doesn't work after deployment:

1. Check the browser console for errors (F12 in most browsers)
2. Verify your API URL in the settings
3. Ensure your backend is running and accessible
4. Check if CORS is properly configured on your backend 