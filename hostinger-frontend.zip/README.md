# Scheduling Assistant Frontend

A modern, responsive frontend for the Scheduling Assistant application, optimized for deployment on Hostinger.

## Overview

This frontend is built with plain HTML, CSS, and JavaScript, making it compatible with any standard web hosting service like Hostinger. It connects to your existing Flask backend API.

## File Structure

- `index.html` - Main HTML file
- `styles.css` - CSS styles
- `config.js` - Configuration settings
- `app.js` - Application logic
- `favicon.ico` - Site favicon

## Deployment to Hostinger

Follow these steps to deploy this frontend to Hostinger:

1. **Log in to your Hostinger account**

2. **Upload Files**
   - Go to File Manager in your Hostinger control panel
   - Navigate to your domain's public_html directory
   - Upload all files from this folder to the public_html directory
   - Alternatively, you can use FTP to upload the files

3. **Configure API Connection**
   - Once deployed, visit your website
   - Click the settings icon (gear) in the chat interface
   - Enter your API backend URL (e.g., `https://your-api-domain.com/api/chat`)
   - If your API requires authentication, enter your API key
   - Click "Save Settings"

## Backend API Requirements

Your existing Flask backend already meets these requirements, but for reference, the frontend expects:

1. POST requests to the endpoint `/api/chat` with JSON containing a `message` field:
   ```json
   { "message": "I want to schedule a window cleaning service" }
   ```

2. Response with JSON containing a `response` field:
   ```json
   { "response": "I'd be happy to help schedule that. When would you like the service?" }
   ```

3. A health check endpoint at `/api/health` (optional but recommended)

## Running Your Existing Flask Backend

Your Flask application (`app.py`) is already set up correctly with:
- CORS configuration to allow cross-domain requests
- The correct API endpoints for chat and health checks
- Proper error handling

To run your backend:

1. Ensure your environment variables are set in the `.env` file:
   ```
   SUPABASE_URL=your_supabase_url
   SUPABASE_KEY=your_supabase_key
   OPENAI_API_KEY=your_openai_api_key
   ```

2. Run the start script:
   ```bash
   ./start-scheduling.sh
   ```

3. Your backend will be available at http://localhost:5001

## Deployment Options for the Backend

To make your backend accessible from your Hostinger frontend:

1. **VPS/Dedicated Server**
   - Deploy your Flask app on a VPS from DigitalOcean, Linode, or AWS EC2
   - Use a reverse proxy like Nginx or Apache
   - Consider setting up a domain or subdomain for your API

2. **PaaS Options**
   - Heroku: Easy deployment with `Procfile` and `requirements.txt`
   - Render: Similar to Heroku with simple Git-based deployments
   - PythonAnywhere: Good for Python-specific applications

3. **Serverless Options**
   - AWS Lambda with API Gateway
   - Google Cloud Functions
   - Azure Functions

Remember to update your CORS settings in production to only allow your specific frontend domain:

```python
from flask_cors import CORS
app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "https://your-frontend-domain.com"}})
```

## Troubleshooting

If the assistant doesn't work after deployment:

1. Check the browser console for errors (F12 in most browsers)
2. Verify your API URL in the settings
3. Ensure your backend is running and accessible
4. Check if CORS is properly configured on your backend
5. Test your backend with the included `test-api.py` script 